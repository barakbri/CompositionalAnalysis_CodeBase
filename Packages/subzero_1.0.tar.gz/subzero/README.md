# Subzero

# The package contains a simple implementation of the Wilcoxon rank sum test, with correction for ties.
# Allows computing P-value by permutations. 
