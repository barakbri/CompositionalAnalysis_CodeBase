getCounts <- function(y) as.matrix(y$counts)
