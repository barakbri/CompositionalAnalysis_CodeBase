cpm <- function(y, ...)
UseMethod("cpm")

cpm.DGEList <- function(y, normalized.lib.sizes=TRUE, log=FALSE, prior.count=2, ...)
#	Counts per million for a DGEList
#	Davis McCarthy and Gordon Smyth.
#	Created 20 June 2011. Last modified 26 Oct 2018.
{
	lib.size <- y$samples$lib.size
	if(normalized.lib.sizes) lib.size <- lib.size*y$samples$norm.factors
	cpm.default(y$counts,lib.size=lib.size,log=log,prior.count=prior.count)
}

cpm.default <- function(y, lib.size=NULL, log=FALSE, prior.count=2, ...)
#	Counts per million for a matrix
#	Davis McCarthy and Gordon Smyth.
#	Created 20 June 2011. Last modified 26 Oct 2018.
{
#	Check y
	y <- as.matrix(y)
	if (any(dim(y)==0L)) {
		return(y)
	}
  
#	Check lib.size
	if(is.null(lib.size)) lib.size <- colSums(y)
	if(!is.double(lib.size)) {
		if(!is.numeric(lib.size)) stop("lib.size must be numeric")
		storage.mode(lib.size) <- "double"
	}
	lib.size <- makeCompressedMatrix(lib.size, dim(y), byrow=TRUE)

    check.range <- suppressWarnings(range(lib.size))
    if (any(is.na(check.range)) || check.range[1] <= 0) {
        stop("library sizes should be finite and non-negative")
    }

#	Calculating in C++ for max efficiency
	if(log) {
		prior.count <- .compressPrior(y, prior.count)
		out <- .Call(.cxx_calculate_cpm_log, y, lib.size, prior.count)
	} else {
		out <- .Call(.cxx_calculate_cpm_raw, y, lib.size)
	}

#	Cleaning up
	dimnames(out) <- dimnames(y)
	out
}
