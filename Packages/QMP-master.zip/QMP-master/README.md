# QMP
Quantitative Microbiome Profiling

An R-script covering the different steps of quantitative microbiome profiling (QMP) as described in the article 'Quantitative microbiome profiling links gut community variation to microbial load'
