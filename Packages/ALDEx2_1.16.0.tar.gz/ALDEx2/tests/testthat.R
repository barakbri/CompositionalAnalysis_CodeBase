library(testthat)
library(ALDEx2)

test_check("ALDEx2")
