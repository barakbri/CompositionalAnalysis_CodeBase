library(testthat)
library(dacomp)

test_check("dacomp")
