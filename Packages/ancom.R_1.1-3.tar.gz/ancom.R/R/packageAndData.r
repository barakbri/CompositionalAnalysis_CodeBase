##
## This is the PACKAGE documentation
##

#' ancom.R
#' 
#' @docType package
#' @name ancom.R-package
#' @rdname ancom.R-package
#' 
#' @description
#' The ANCOM method.
#'
#' @details
#' \tabular{ll}{
#' Package: \tab ancom.R\cr
#' Type:    \tab Package\cr
#' Version: \tab 1.1-2\cr
#' Date:    \tab 2015-07-09\cr
#' License: \tab GLP-3  \cr
#' }
#' 
#' @import methods
#' @import stats
#'
#' 
#' 
NULL





